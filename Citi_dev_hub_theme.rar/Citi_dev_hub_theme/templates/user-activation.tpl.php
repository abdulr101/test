<?php
global $base_path;
$theme_path = $base_path . drupal_get_path('theme', 'citi_custom_theme');
?>
<!-- Modal One -->
        <div id="modal-login" class="modal fade city-modal" role="dialog">
            <div class="modal-dialog modal-md Group-24">
                <!-- Modal content-->
                <div class="modal-content Rectangle-6-Copy" style="
                    width: 900px;
                    height: 1257px;margin-left: -154px;border-radius:0;">
                    <div class="modal-header">
                        <div class="Activate">
                            <button type="button" class="close Circle-Fill" data-dismiss="modal"></button>
                            <h1 class="modal-title">Activate</h1>
                        </div>
                    </div>
                    <div class="modal-body">
                        <h2 class="heading"><img src="<?php print $theme_path;?>/images/userlock.png"  width="80px" height="80px"> <span>Welcome to the Citi Developer Hub </span></h2>
                        <div class="form-element">
                            <div class="row-1">
                                <div class="col-1"><input class="form-control one" type="text" required placeholder="First Name"></div>
                                <div class="col-2"><input class="form-control one" type="text" required placeholder="Last Name"></div>
                            </div>
                            <div class="row-1">
                                <div class="col-1"><?php print $mail;?></div>
                                <div class="col-2"><input class="form-control one" type="text" placeholder="Company"></div>
                            </div>
                        </div>
                        <h2 class="ttl-2 heading2">Please create a User ID and Password</h2>
                        <div class="createuser">
                            <div class="row-1">
                                <div class="col-1"><?php print $name;?></div>
                                <div class="col-2"><input class="form-control one" type="text" style="display:none;"></div>
                            </div>
                            <div class="row-1">
                                <div class="col-1"><input class="form-control one" type="text" placeholder="Password"></div>
                                <div class="col-2"><input class="form-control one" type="text" placeholder="Confirm Password"></div>
                            </div>
                        </div>
                        <h2 class="ttl-2 heading3">CAPTCHA</h2>
                        <div class="row-1 captcha-container">
                            <div class="col-1 font-12 This-question-is-for"><span class="captcha-message">This question is for testing weather you
are a human visitor and to prevent
automated spam submissions.</span></div>
                            <div class="col-2">
                                <img src="<?php print $theme_path;?>/images/captcha.png" width="182" height="64" /> <br clear="all" />
                                <input class="form-control one" placeholder="What is the text on the image?" type="text">
                            </div>
                        </div>

                        <div class="row-1 terms-align">
                            <div class="check-align-1">
                                <input type="checkbox" id="check-1" required>
                                <span for="check-1"></span>
                            </div>
                            <div class="accept-link">I accept the <a href="#">Terms and Conditions</a></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                            <a class="btn btn-default cancel" href="#"><span class="butchnge">Cancel</span></a> 
                            <a class="btn btn-info continue"  href="#"><span class="butchnge">Continue</span></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal One Ends -->