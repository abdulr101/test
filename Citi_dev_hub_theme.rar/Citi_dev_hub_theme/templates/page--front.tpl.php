<?php
global $user, $base_url;
	if($user->uid){
		$api_url= $base_url.'/api';
		header("location: $api_url");
		exit;
	}else{

//  global $user;
//  print render($page['header']);
//  print_r($_POST);
if (!$user->uid ) {
	$elements = drupal_get_form('user_login');     
        $rendered = drupal_render($elements);
	module_load_include('inc', 'user', 'user.pages');
	$elements_pass = drupal_get_form('user_pass');
	$rendered1 = render($elements_pass);
}
 //$themepath = path_to_theme(); -->	
	
global $base_path;
$theme_path = $base_path . drupal_get_path('theme', 'Citi_dev_hub_theme');
$errors = drupal_get_messages('error');
//echo '<pre>';
//print_r($errors);
$login_error=0; $requestpassword_error=0;
if(isset($errors['error']) && $errors['error'][0]!=""){
	if(strstr($errors['error'][0], "unrecognized username or")){
		$login_error=1;
	}
	
}
 
if($login_error > 0){
	
	$error_message= "You have entered incorrect credentials.";  
}else{ $error_message="";}
?>
<div class="body-container">
<!--Header starts-->
        <div class="container-fluid header-out">
            <div class="container">
                <div class="headet">				
				<a href="javascript: void(0);"><img class="logo" src="<?php print $theme_path;?>/images/logo_new.png" style="position:relative; margin-left:78px;" /></a></div>
            </div>
        </div>
        <!--Header ends-->
        <!--banner starts-->
        <div class="container-fluid main-banner-out">
            <div class="container">
                <div class="main-banner"><img class="logo" src="<?php print $theme_path;?>/images/main-banner.png" /></div>
            </div>
        </div>
        <!--banner ends-->
        <!--content one starts-->
        <div class="container-fluid content1-out">
            <div class="container content1-in">
                <div class="content1">
               
		<?php 
			$elements = drupal_get_form('user_login');     
       			 $rendered = drupal_render($elements);
		
		$output ='<form action="' . $elements['#action'] .
                                      '" method="' . $elements['#method'] .
                                      '" id="' . $elements['#id'] .
                                      '" accept-charset="UTF-8">
		 
                    <div class="login">
                        <h2><img src="'.$theme_path.'/images/login.png" height="50" width="50" /><span class="Login-text"> Log In</span></h2>
                        <div class="row" style="
    margin-bottom: 26px;
">
                            <div class="col-md-12">
                              <!--  <span class="ErrorText" style="text-align:center;">'.$error_message.'</span> -->
                               <div class="ErrorText" style="text-align: center;"> <p style="cursor:pointer;color:#ed541d;" class="forgot_error margin-bottom-0" >'.$error_message.'</p></div>     
                                </div>
                        </div>
                        
                        <div class="row-1">'.
				$elements['name']['#children'].'</div>
                        <div class="row-1">'.$elements['pass']['#children'].'</div>
                        <div class="row-1 tac"><a href="javascript: void(0);">Forget User ID or Password?</a></div>
                     <!--   <div class="row-1 drop">
                            <select class="select2">
                                <option>Select Your Default Page</option>
                                <option>duplicate</option>
                                <option>duplicate</option>
                                <option>duplicate</option>
                            </select>
                        </div>  -->
                        <div class="row-1">
                        <div class="col-md-3"></div>
                       <!--     <div class="col-1">
                                <div class="check-align-1">
                                    <input type="checkbox" id="check-1">
                                    <span for="check-1"></span>
                                </div>
Make this page default. (you can change it later)
                            </div>  -->
                            <div class="col-md-6 lgbtn">';

//rahul added
$elements['name']['#attributes']['placeholder'] = "User Id";
					 $output .= $elements['form_build_id']['#children'];
                 $output .= $elements['form_id']['#children'];     
            $elements['submit']['#attributes']['class']  = "Sign On"; 
                 $output .= $elements['actions']['#children'].'</div>
                            <div class="col-md-3"></div>
                        </div>
                    </div>
                    </form>';
 print $output;
?>
                    <div class="hello-dev">
                        <p class="ttl-1">H E L L O , D E V E L O P E R</p>
                        <h2>Our APIs are in closed beta, but we’re working
hard to open them up to everyone.</h2>
                        <div class="img"><img src="<?php print $theme_path;?>/images/img-1.png" /></div>
                    </div>
                </div>
            </div>
        </div>
        <!--content one Ends-->
        <!--API LIst starts-->
        <div class="container-fluid content4-out">
            <div class="container content4-in">
                <div class="content4">
                    <h2 class="api"> Browse Our Complete List of APIs</h2>
            <!--        <div class="more-api">
                        <a href="javascript: void(0);" id="more-api">
                            <i class="fa fa-angle-down" aria-hidden="true"></i>
                            <i class="fa fa-angle-up show1" aria-hidden="true"></i>
                        </a>
                    </div> -->
                    <div class="city-tabs">

                        <div id="parentHorizontalTab">
                            <ul class="resp-tabs-list hor_1">
                                <li>All Regions</li>
                                <li>North America</li>
                                <li>EMEA</li>
                                <li>APAC</li>
                                <li>Mexico</li>
                            </ul>
                            <div class="resp-tabs-container hor_1">
                                <div>

                                    <div class="row-1">
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>

                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                    </div>
                                    <div class="row-1">
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>

                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                    </div>
                                    <div class="row-1">
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>

                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                    </div>



                                </div>
                                <div>
                                    <div class="row-1">
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>

                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                    </div>



                                </div>
                                <div>
                                    <div class="row-1">
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>

                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                    </div>
                                    <div class="row-1">
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>

                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div class="row-1">
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>

                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                    </div>
                                    <div class="row-1">
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>

                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                    </div>
                                    <div class="row-1">
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>

                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div class="row-1">
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>

                                        <div class="col-1">
                                            <span class="img"><img src="<?php print $theme_path;?>/images/img-4.png" /></span>
                                            <div class="disc"><h2>Rewards</h2>
                                                <p>Lorem ipsum dolors epsilon sunt. Sit amet.</p></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>




        <!--API LIst Ends-->
        <!--content 2 starts-->
        <div>
            <div class="container content2-in">
                <div class="content2 car-1">
                    <div id="myCarousel" class="carousel slide" data-ride="carousel">

                        <div class="carousel-inner" role="listbox">
                            <div class="item active clearfix">
                                <div class="col1"><img src="<?php print $theme_path;?>/images/pay-with-points-photo.png" alt=""></div>
                                <div class="col2 clearfix">
                                    <p class="ttl-1 clearfix">MOBILE PAYMENTS</p>
                                    <h2>Pay with Points</h2>
                                    <p class="txt-1 clearfix">Lorem ipsum dolor sit amet, consectetur adipiscing elit, is
exercitation ullamcnisi ut aliquip ex ea commodo consequat.</p>
                                    <p class="txt-2 clearfix"><img src="<?php print $theme_path;?>/images/tools.png" />
									<span>Sony Xperia Z5 Compact, Nexus 6P, iPhone 6S Plus,
iPhone 6S, Sony Xperia Z5, LG G5, OnePlus 3, HTC 10</span></p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="col1"><img src="<?php print $theme_path;?>/images/pay-with-points-photo.png" alt=""></div>
                                <div class="col2 clearfix">
                                    <p class="ttl-1 clearfix">MOBILE PAYMENTS</p>
                                    <h2>Pay with Points</h2>
                                    <p class="txt-1 clearfix">Lorem ipsum dolor sit amet, consectetur adipiscing elit, is
exercitation ullamcnisi ut aliquip ex ea commodo consequat.</p>
                                    <p class="txt-2 clearfix"><img src="<?php print $theme_path;?>/images/tools.png" />
									<span>Sony Xperia Z5 Compact, Nexus 6P, iPhone 6S Plus,
iPhone 6S, Sony Xperia Z5, LG G5, OnePlus 3, HTC 10</span></p>
                                </div>
                            </div>
                            <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                                <img src="<?php print $theme_path;?>/images/left-aro1.png"  onmouseover="this.src='<?php print $theme_path;?>/images/left-aro.png'" onmouseout="this.src='<?php print $theme_path;?>/images/left-aro1.png'"  alt=""> 
                            </a>
                            <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                                 <img src="<?php print $theme_path;?>/images/right-aro1.png"  onmouseover="this.src='<?php print $theme_path;?>/images/right-aroo2.png'" onmouseout="this.src='<?php print $theme_path;?>/images/right-aro1.png'"alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--content 2 Ends-->
        <!--content 3 Starts-->
        <div class="container-fluid content3-out">
            <div class="container content3-in">
                <div class="content3">
                    <h2> <span>B I G N A M E S , B I G G E R R E S U LT S</span> </h2>
                    <div class="row-1">
                        <img src="<?php print $theme_path;?>/images/icn-1.png" alt="">
                        <img src="<?php print $theme_path;?>/images/icn-2.png" alt="">
                        <img src="<?php print $theme_path;?>/images/icn-3.png" alt="">
                        <span class="two"></span>
                        <img src="<?php print $theme_path;?>/images/icn-4.png" alt="">
                        <img src="<?php print $theme_path;?>/images/icn-5.png" alt="">
                        <img src="<?php print $theme_path;?>/images/icn-6.png" alt="">
                        <span class="one"></span>
                        <img src="<?php print $theme_path;?>/images/icn-7.png" alt="">
                        <img src="<?php print $theme_path;?>/images/icn-8.png" alt="">
                        <img src="<?php print $theme_path;?>/images/icn-9.png" alt="">
                        <span class="two"></span>
                        <img src="<?php print $theme_path;?>/images/icn-10.png" alt="">
                        <img src="<?php print $theme_path;?>/images/icn-11.png" alt="">
                        <img src="<?php print $theme_path;?>/images/icn-12.png" alt="">
                    </div>
                </div>
            </div>
        </div>
        <!--content 3 Ends-->
        <!--Footer Starts-->
        <div class="container-fluid footer-out">
            <div class="container">
                <div class="footer">
                    <div class="col-1"><img src="<?php print $theme_path;?>/images/foo-1.png" alt=""></div>
                    <div class="col-2">
                        <div class="row-1"><a href="javascript: void(0);">Contact Us </a>
                            <a href="javascript: void(0);">Privacy  </a>
                            <a href="javascript: void(0);">Security  </a>
                            <a href="javascript: void(0);">Careers  </a>
                            <a href="javascript: void(0);">About Us  </a>
                            <a href="javascript: void(0);">Site Map  </a>
                            <a href="javascript: void(0);">Terms & Conditions </a></div>
                        <div class="row-1">Citibank.com is the source of information about and access to U.S. domestic financial services provided by Citibank retail banking and the Citigroup family of companies and
is intended for use domestically in the U.S. Terms, conditions and fees for accounts, products, programs and services are subject to change. Not all accounts, products, and
services as well as pricing described here are available in all jurisdictions or to all customers. Your country of citizenship, domicile, or residence, if other than the United
States, may have laws, rules, and regulations that govern or affect your application for and use of our accounts, products and services, including laws and regulations
regarding taxes, exchange and/or capital controls that you are responsible for following. NMLS ID: 412915</div>
                        <div class="row-1">Copyright © 2016 Citigroup Inc</div>
                    </div>
                </div>
            </div>
        </div>
        <!--Footer Ends-->
</div>
<?php } ?>
