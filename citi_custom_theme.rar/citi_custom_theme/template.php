<?php
// ibm_apim_theme
// based on sky by Adaptivethemes.com

/**
 * Override or insert variables into the html template.
 */
function citi_custom_theme_preprocess_html(&$vars) {
  global $theme_key;
  $theme_name = $theme_key;

  // Add a class for the active color scheme
  if (module_exists('color')) {
    $class = check_plain(get_color_scheme_name($theme_name));
    $vars['classes_array'][] = 'color-scheme-' . drupal_html_class($class);
  }

  // Add class for the active theme
  $vars['classes_array'][] = drupal_html_class($theme_name);

  // Add theme settings classes
  $settings_array = array(
    'box_shadows',
    'body_background',
    'menu_bullets',
    'menu_bar_position',
    'content_corner_radius',
    'tabs_corner_radius');
  foreach ($settings_array as $setting) {
    $vars['classes_array'][] = at_get_setting($setting);
  }
  // add class for role
  if (isset($vars['user']) && isset($vars['user']->roles)) {
    foreach($vars['user']->roles as $role){
      $vars['classes_array'][] = 'role-' . drupal_html_class($role);
    }
  }
}

/**
 * Override or insert variables into the html template.
 */
function citi_custom_theme_process_html(&$vars) {
  // Hook into the color module.
  if (module_exists('color')) {
    _color_html_alter($vars);
  }
}
/**
* Add placeholder to login block input fields - Rahul
*/
function citi_custom_theme_form_user_login_block_alter(&$form) {
	//print_r($form);	
	$form['name']['#attributes']['placeholder'] = t('User Id');
	$form['pass']['#attributes']['placeholder'] = t('Password');
	 $form['name']['#attributes']['required'] = 'required';
      $form['pass']['#attributes']['required'] = 'required';
	return $form;
}

/*


*/


function citi_custom_theme_form_alter(&$form, &$form_state, $form_id){
	if($form_id=="user_pass"){
		$form['name']['#attributes']['placeholder'] = t('User Id or Email Address');
		$form['submit']['#value'] = t('Request New Password');
	}
	if($form_id == "user_login") {
	  $form['actions']['submit']['#attributes']['class'][] = 'btn btn-info';
	}

}

/**
 * Override or insert variables into the page template.
 */
function citi_custom_theme_preprocess_page(&$vars, $hook) {
  //print_r($vars['theme_hook_suggestions']);exit;
  if ($vars['page']['footer'] || $vars['page']['four_first'] || $vars['page']['four_second'] || $vars['page']['four_third'] || $vars['page']['four_fourth']) {
    $vars['classes_array'][] = 'with-footer';
  }

  if (isset($vars['node']->type)) {
    // If the content type's machine name is "my_machine_name" the file
    // name will be "page--my-machine-name.tpl.php".
    $vars['theme_hook_suggestions'][] = 'page__' . $vars['node']->type;
    if (isset($vars['view_mode'])) {
      // If the content type's machine name is "my_machine_name" and the view mode is "teaser" the file
      // name will be "page--my-machine-name--teaser.tpl.php".
      $vars['theme_hook_suggestions'][] = 'page__' . $vars['node']->type . '__' . $vars['view_mode'];
    }
  }
  if (drupal_is_front_page() || (arg(0) == 'ibm_apim' && arg(1) == 'activate')) {
    drupal_add_css(drupal_get_path('theme','citi_custom_theme'). '/css/bootstrap.min.css');
    drupal_add_css(drupal_get_path('theme','citi_custom_theme'). '/css/font-awesome.min.css');
    drupal_add_css(drupal_get_path('theme','citi_custom_theme'). '/css/easy-responsive-tabs.css');
    drupal_add_css(drupal_get_path('theme','citi_custom_theme'). '/css/style.css');
    
    //drupal_add_js(drupal_get_path('theme','citi_custom_theme'). '/js/jquery.min.js');
    drupal_add_js(drupal_get_path('theme','citi_custom_theme'). '/js/bootstrap.min.js');
    drupal_add_js(drupal_get_path('theme','citi_custom_theme'). '/js/easyResponsiveTabs.js');
    drupal_add_js(drupal_get_path('theme','citi_custom_theme'). '/js/front.js');
  }
}

/**
 * Override or insert variables into the page template.
 */
function citi_custom_theme_process_page(&$vars) {
  // Hook into the color module.
  if (module_exists('color')) {
    _color_page_alter($vars);
  }
}

/**
 * Override or insert variables into the block template.
 */
function citi_custom_theme_preprocess_block(&$vars) {
  if ($vars['block']->module == 'superfish' || $vars['block']->module == 'nice_menu') {
    $vars['content_attributes_array']['class'][] = 'clearfix';
  }
  if (!$vars['block']->subject) {
    $vars['content_attributes_array']['class'][] = 'no-title';
  }
  if ($vars['block']->region == 'menu_bar' || $vars['block']->region == 'top_menu') {
    $vars['title_attributes_array']['class'][] = 'element-invisible';
  }
}

/**
 * Override or insert variables into the node template.
 */
function citi_custom_theme_preprocess_node(&$vars) {
  // Add class if user picture exists
  if (!empty($vars['submitted']) && $vars['display_submitted']) {
    if ($vars['user_picture']) {
      $vars['header_attributes_array']['class'][] = 'with-picture';
    }
  }
}

/**
 * Override or insert variables into the comment template.
 */
function citi_custom_theme_preprocess_comment(&$vars) {
  // Add class if user picture exists
  if ($vars['picture']) {
    $vars['header_attributes_array']['class'][] = 'with-user-picture';
  }
}

/**
 * Process variables for region.tpl.php
 */
function citi_custom_theme_process_region(&$vars) {
  // Add the click handle inside region menu bar
  if ($vars['region'] === 'menu_bar') {
    $vars['inner_prefix'] = '<h2 class="menu-toggle"><a href="#">' . t('Menu') . '</a></h2>';
  }
}

function citi_custom_theme_menu_alter(&$items) {
  $items['user']['title callback'] = 'ibm_apim_theme_user_menu_title';
}

function citi_custom_theme_user_menu_title() {
  global $user;
  return user_is_logged_in() ? $user->name : t('User account');
}

function citi_custom_theme_menu_tree__user_menu(&$variables) {
  global $user;
  drupal_add_js('jQuery(document).ready(function(){
      jQuery(".dropitmenu").dropit();
    });', 'inline');
  $output = '<ul class="dropitmenu"><li title="' . $user->name . '"><a href="#"><div class="elipsis-names">' . $user->name . '</div> <span class="dropit-icon ui-icon-triangle-1-s" style="display: inline-block;"></span></a><ul id="dropdown-menu" class="dropdown-menu">' . $variables['tree'] . '</ul></li></ul>';

  return $output;
}

function citi_custom_theme_theme(&$existing, $type, $theme, $path) {
  $hooks['user_login'] = array(
    'template' => 'templates/user_login',
    'render element' => 'form',
  );
  $hooks['ibm_apim_activate_create_account_form'] = array(
    'template' => 'templates/user-activation',
    'render element' => 'form',
  );  
  
  return $hooks;
}

function citi_custom_theme_preprocess_ibm_apim_activate_create_account_form(&$variables) {
  $form = $variables['form'];
  $variables['name'] = render($form['account']['name']);
  $variables['mail'] = render($form['account']['mail']);
  $variables['children'] = drupal_render_children($form);
  //print '<pre>';
  //print_r($form['account']);exit;
}

function citi_custom_theme_preprocess_user_login(&$variables) {
  $form = $variables['form'];
  $variables['name'] = render($form['name']);
  $variables['pass'] = render($form['pass']);
 
  // Be sure to print the remaining rendered form items.
  $variables['children'] = drupal_render_children($form);
}
