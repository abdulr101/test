<div id="modal-login" class="modal fade city-modal" role="dialog">
            <div class="modal-dialog modal-md Group-24">
                <!-- Modal content-->
                <div class="modal-content Rectangle-6-Copy">
                    <div class="modal-header">
                        <div class="Activate">
                            <button type="button" class="close Circle-Fill" data-dismiss="modal"></button>
                            <h1 class="modal-title">User Login</h1>
                        </div>
                    </div>
                    <div class="modal-body">
                        
                        <div class="form-element">
                         <?php print $name;?>
                        </div>
						
						<div class="form-element">
                         <?php print $pass;?>
                        </div>
                        
                        
                    </div>
                    <div class="modal-footer">
                           <?php print $children;?>
                    </div>
                </div>
            </div>
</div>