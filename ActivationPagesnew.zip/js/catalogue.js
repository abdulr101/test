$(function () {
	'use strict';

  // *** For Catalogue ***/
  // Code Samples and Dev Notes
  $('.sh_toggle').on('click', function(){
    $(this).toggleClass('open')
    .parent().next('.cata_drawer').toggleClass('open');
  });
  $('.cata-top').on('click', function() {
    $("html, body").animate({ scrollTop: 0 });
  });

  //controls toogle grid overlay btn
  $('.toggleGridOverlay').click(function(e){
    if($('.gridOverlayContainer').hasClass('gridOverlayOn')){
      $('.gridOverlayContainer').css('height', 0).css('width', 0);
      $('.innerCol').css('height', 'auto');
      $('.page').replaceWith(function(){
        return $(this).contents();
      });   
    } else {
      var pageContent = $('#skippy, #topmost-wrap, body>.component-nav-wrap, body>.mainContent, body>footer.footer');
      pageContent.wrapAll("<div class='page'></div>");
      var contentHeight = $('.page').height();
      $('.page').css('margin-top', '-' + (contentHeight) + 'px');
      $('.gridOverlayContainer').css('width', 'auto');
      $('.gridOverlayContainer, .innerCol').css('height', contentHeight);
    }
    $('.gridOverlayContainer').toggleClass('gridOverlayOn');
    $(e.target).blur();
  });

  /* Theme swap Button Event - START - */
  var $body = $('body');
  var $themeToggles = $('.toggleTheme');
  if ($body.hasClass('theme-dark')) {
    $themeToggles.attr('disabled', 'disabled').html('Blue Theme');
  } else {
    $themeToggles.on('click', function (e) {
      $body.toggleClass('theme-light');
      if ($body.hasClass('theme-light')) {
        e.currentTarget.innerHTML = 'Gray Theme';
        $('.theme-light:not(body)').removeClass('theme-light').addClass('theme-gray');
      } else {
        e.currentTarget.innerHTML = 'Light Theme';
        $('.theme-gray:not(body)').addClass('theme-light').removeClass('theme-gray');
      }
    });
  }
  /* Theme swap Button Event - End - */

  // Controls sublist toggles in dev notes
  $('.cata-toggle-sublist').on('click', function () {
    $(this).parent().toggleClass('cata-is-collapsed')
  });


  // *** FOR EXAMPLES ***/
	$('#btn-test-progressbar-animation').on("click", function(){
     	$('#test-percentage-indicator').data('percentageProgressIndicator').updateProgress(0.0);
     	
     	var i = 0;
     	var testAnim = setInterval(function(){
     		i++;
     		if(i == 10){
     			clearInterval(testAnim);
     		}
			$('#test-percentage-indicator').data('percentageProgressIndicator').updateProgress(i*10);	
     	}, 500);
  });

  $('form','#SampleErrorStates').submit(function(e){
  	e.preventDefault();
  	var errorClass = 'validation-input-danger';
  	var $uid = $('#UserIdLogin');
  	var $uidError = $('#UserIdLoginError');
  	var $pass = $('#PasswordLogin');
  	var $passError = $('#PasswordLoginError');

  	$('.sr-only','label').remove();

  	// Check user id
  	if ($uid.val() === '' ) {
  		var $label = $('#UserIdLoginLabel');
  		$uid.addClass(errorClass);
  		$uidError.removeClass('hidden');
  		var labelUpdate = ''+ $label.text() +' <span class=\"sr-only\">error: '+ $uidError.text() +'</span>';
  		$label.html(labelUpdate);
  	} else {
  		$uid.removeClass(errorClass);
  		$uidError.addClass('hidden');
  	}
  	// Check Password
  	if ($pass.val() === '' ) {
  		var $label = $('#PasswordLabel');
  		$pass.addClass(errorClass);
  		$passError.removeClass('hidden');
  		var labelUpdate = ''+ $label.text() +' <span class=\"sr-only\">error: '+ $passError.text() +'</span>';
  		$label.html(labelUpdate);
  	} else {
  		$pass.removeClass(errorClass);
  		$passError.addClass('hidden');
  	}

  	$('.'+ errorClass).first().focus();
  });

  // Module Configurator -START-
  var $Configurator = $('#Module-Configurator');
  var $HeaderContainer = $('#Header-Container');
  var $ContentContainer = $('#Content-Container');
  var $FooterContainer = $('#Footer-Container');
  var $AppliedModuleCardsContainer = $('#Applied-Module-Cards');
  var $ModuleCards = $('#Module-Cards');
  var $UrlOutput = $('.url-output');
  var $ModuleLink = $('.module-link');

  if ($Configurator.length > 0) {
    var queryModules = getQueryStringVars();
    var moduleList = [];
    var moduleName = '';
    var appliedModuleCardsHTML = '';
    
    if (queryModules) {
      for (var i = 0; i < queryModules.length; i++) {
        
      // }
      // for (moduleName in queryModules) {
        var currentModule = $('[data-id='+queryModules[i].name+']');
        if (currentModule.length > 0) {
          currentModule = currentModule[0];
          if (queryModules[i].name.toLowerCase().indexOf('header') !== -1) {
            $HeaderContainer.empty();
            $HeaderContainer.innerHTML = currentModule.innerHTML;
          } else if (queryModules[i].name.toLowerCase().indexOf('footer') !== -1) {
            $FooterContainer.empty();
            $FooterContainer.innerHTML = currentModule.innerHTML;
          } else {
            var currentClassname = '';
            if (queryModules[i].class !== undefined) {
              currentClassname = queryModules[i].class.split('.').join(' ');
            }
            var cardName = $ModuleCards.find('[data-card-id='+queryModules[i].name+']').text().replace(new RegExp('Add$'), '');
            var moduleClone = document.createElement('div');
            appliedModuleCardsHTML += '<div id="module-cards" class="module-card" data-card-id="'+queryModules[i].name+'">'+cardName+'<button class="remove-module"><span class="sr-sm-only">Remove</span></button></div>';
            moduleClone.innerHTML = currentModule.innerHTML;

            moduleClone.firstElementChild.className += ' '+currentClassname;
            moduleList.push(moduleClone.childNodes);
          }
        } else {
          if (queryModules[i].name === 'theme') {
            $Configurator.addClass('theme-'+queryModules[queryModules[i].name]);
          }
        }
      }
    } else {
      $('#module-configuration-modal').modal('show');
    }
    $AppliedModuleCardsContainer.append(appliedModuleCardsHTML);
    $ContentContainer.append(moduleList);
    UpdatePrototypeUrl();

    $AppliedModuleCardsContainer.sortable({
      evert: true,
      stop: function (e, ui) {
        ui.item[0].setAttribute('style', '');
        UpdatePrototypeUrl();
      },
      receive: function ( event, ui ) {
        var newCard = $AppliedModuleCardsContainer.find('.ui-draggable-handle');
        var addBtn = $(ui.item[0]).find('.add-module');
        addBtn.addClass('recently-added');
        window.setTimeout(function () {        
          addBtn.removeClass('recently-added');
        }, 1500);
        // console.log($ModuleCards.find('[data-card-id='+ui.item[0].getAttribute('data-card-id')+']'));
        newCard
          .removeClass('ui-draggable ui-draggable-handle')
          .find('button')
            .html('<span class="sr-sm-only">Remove</span>')
            .removeClass('add-module')
            .addClass('remove-module')
            .on('click', function (e) {
              $(e.currentTarget).closest('.module-card').remove();
              UpdatePrototypeUrl();
            });
        UpdatePrototypeUrl();
      }
    });
    $ModuleCards.find('.module-card').draggable({
      connectToSortable: '#Applied-Module-Cards',
      helper: 'clone',
      revert: 'invalid'
    });

    var $RemoveBtns = $('.remove-module');
    var $AddBtns = $('.add-module');

    $AddBtns.on('click', function (e) {
      var addBtn = $(e.currentTarget);
      var cardId = addBtn.closest('.module-card').attr('data-card-id');
      var cardName = addBtn.closest('.module-card').text().replace(new RegExp('Add$'), '');
      addBtn.addClass('recently-added');
      window.setTimeout(function () {        
        addBtn.removeClass('recently-added');
      }, 1500);
      var newCard = document.createElement('div');
      var removeBtn = document.createElement('button');
      newCard.className = 'module-card';
      newCard.setAttribute('data-card-id', cardId);
      newCard.innerHTML = cardName;
      removeBtn.className = 'remove-module';
      removeBtn.innerHTML = '<span class="sr-sm-only">Remove</span>';
      newCard.appendChild(removeBtn);
      $AppliedModuleCardsContainer.append(newCard);
      $(removeBtn).on('click', function (e) {
        $(e.currentTarget).closest('.module-card').remove();
        UpdatePrototypeUrl();
      });
      UpdatePrototypeUrl();

    });
    $RemoveBtns.on('click', function (e) {
      $(e.currentTarget).closest('.module-card').remove();
      UpdatePrototypeUrl();
    });
  }
  // Module Configurator -END-

	//Init infinite scroll example
	$('.btn-inf-scroll').on('click', function(e){
		// NOTE: Parts of this function is for simulation only
		// 'infTable' is where marked up data needs appending

    e.preventDefault();
    var btn = $(this);
    var jamp  = btn.next();
    var $el    = btn.closest('.row').prev();
    var $table = $el.find('table');
    var $thead = $('thead', $el);
    var $tbody = $('tbody', $el);
    var $rows  = $('tr', $tbody);

    // Update button text
    btn.hide();
    jamp.toggleClass('hidden', false).attr('aria-hidden', 'false');

    $table.attr('aria-busy','true');

    // ## Start simulated AJAX ## //
    // Simulates up to 2 AJAX calls for the infinite scrolling table
    // Timeout used for server response time simulation
    setTimeout(function(){
        var markup = '#table-inf-scroll-data-1 tr';
        var btn_id = btn.attr('id');
        var oldRowCount = $rows.length;

        if (btn_id == 'tbl-inf-scroll-data-2') {
            markup = '#table-inf-scroll-data-2 tr';
        } else {
            btn.attr('id', 'tbl-inf-scroll-data-2');
        }
        // Get and append formatted rows to table, set focus to first new cell
        $tbody.append( $(markup).clone() );
        $rows = $('tr', $tbody);

        var firstAddedCell = $( $rows[oldRowCount] ).find('td:first-child');
        firstAddedCell.attr('tabindex',0).focus();
        // Remove the tabindex attribute on blur
        firstAddedCell.one('blur', function () {
        	$(this).removeAttr('tabindex');
        });
        $table.removeAttr('aria-busy');

        // Update button text
        jamp.toggleClass('hidden', true).attr('aria-hidden', 'true');
        btn.show();

        // Remove button if 30 rows or no more data
        if (btn_id == 'tbl-inf-scroll-data-2') {
            btn.remove();
        }
    }, 2000);
    // ## End simulated AJAX ## //
	});

  /* FULL HYBRID FORM EXAMPLE */
  $('.Hybrid-Form-Advancer, .Paginated-Form-Advancer').click(function () {
    //Advance next step
    var $el = $(this);
    var idr = "FormStep-";
    var $showing = $('.hybrid-demo-active');
    var frmStep = parseInt($showing.attr('data-toggle').replace(idr, '')) + 1;
    var frmStepMax = $('.hybrid-demo').length;

    if ($el.hasClass('Paginated-Form-Advancer')) {
      var weGood = true;
      
      weGood = paginated_form__store($el, 'step'+ (frmStep - 1));
      if (weGood === false) {
        return false;
      }
    }

    if ($el.attr('data-function') == "store-final") {
      if (catalogue_validation.demoValidate_terms($el) === false) {
        return false;
      }
    }
    
    if (frmStep <= $('.hybrid-demo').length){
      var nextForm = $('[data-toggle='+idr+frmStep+']');

      $showing.toggleClass('hybrid-demo-active', false);
      nextForm.toggleClass('hybrid-demo-active', true);

      if (frmStep == frmStepMax) {
        $el.hide();
      }
    }

    switch ( $el.attr('data-function') ) {
        case 'store':
          hybrid_form__store('account-table-personal','-placeholder');
          hybrid_form__store('account-table-address','-placeholder');
          hybrid_form__store('account-table-security','-placeholder');
          break;
        case 'store-final':
          hybrid_form__store('account-table-personal','-placeholder-final');
          hybrid_form__store('account-table-address','-placeholder-final');
          hybrid_form__store('account-table-security','-placeholder-final');
          break;
    }
    $('.progress-indicator-wrapper + h1', nextForm).focus();
  });
  $('.Hybrid-Form-Devancer').click(function (e){
    e.preventDefault();

    var $el = $(this);
    var idr = "FormStep-";
    var $showing = $('.hybrid-demo-active');
    var frmStep = parseInt($showing.attr('data-toggle').replace(idr, '')) - 1;
    
    if (frmStep >= 0){
      $showing.toggleClass('hybrid-demo-active', false);
      $($("[data-toggle='FormStep-1']").toggleClass('hybrid-demo-active', true).find('.category')[0]).click()
    }
  });
  function hybrid_form__store(from, to){
    $('#'+from+to).html('');
    $('#'+from).clone().appendTo('#'+from+to);
  }
  function paginated_form__store(e, step) {
    if (step == "step1") {
      // Validate
      var weGood = catalogue_validation.demoValidate_paginated(e);
      if (weGood === false) {
        return false;
      }
    }

    var currentForm = $('.hybrid-demo-active');
    var panelSummary = currentForm.next().find('.form-summary');
    var formInput = $('input, select, label', currentForm);
    var values = {};

    // Get Values
    formInput.each(function() {
        var inputEl = $(this);
        var key = inputEl.attr('id');
        var value = inputEl.val();

        if (inputEl.is('select')) {
            value = $('option:selected:not(:first-child)', this).text();
        } else if (inputEl.is('label')) {
            if (inputEl.is('[data-output-value]')) {
                value = inputEl.attr('data-output-value');
            } else {
                value = inputEl.html();
            }
        }

        values[key] = value;
    });
    
    // Output Values
    for (var currentKey in values) {
        var prefix = '';
        var suffix = '';
        var dataDest = panelSummary.find('[data-input-value='+currentKey+']');
        if (dataDest.length > 0 && values[currentKey] !== '') {
            if (dataDest.is('[data-suffix],[data-prefix]')) {
                prefix = dataDest.attr('data-prefix') || '';
                suffix = dataDest.attr('data-suffix') || '';
            }
            dataDest.html(prefix+values[currentKey]+suffix);
        }
    }
  }
  /* end FULL HYBRID FORM EXAMPLE */

  // Hybrid form Example
  /***************************************************************************/
  $('.accordion').each(function () {
    $('.next-step', this).click(function (e){
        e.preventDefault();
        /* your validation script */
        var validated = catalogue_validation.demoValidate_accordion(e);

        /* if valid, update. */
        if (validated === true) {
            CM.AccordionForm._updateOutput(e);

            if ($(this).hasClass('next-step-last')) {
              $('.Hybrid-Form-Advancer.hidden').removeClass('hidden');
            }
        }
    });
  });

  var catalogue_validation = {
    demoValidate_accordion: function(e) {
      'use strict';
      
      var $this = $(e.currentTarget);
      var accordionItem = $this.closest('.parent');
      var formInput = $('input, select', accordionItem);
      var weGood = true
      var msg = 'Field cannot be blank';
      var firstError = true;

      formInput.each(function() {
        var inputEl = $(this);
        if (inputEl.prop('required') == '') {
          return 'non-false'; //continue
        }
        var value = inputEl.val();

        inputEl.removeClass('validation-input-danger')
        .parent().find('.validation-message-danger').remove();

        if (inputEl.is(':checkbox')) {
          return false; 
          //This T&C checkbox will be validated in demoValidate_terms()
        }
        else if (inputEl.is('select')) {
            value = $('option:selected:not(:first-child)', inputEl).text();
            msg = 'Please make a selection'
        }
        if (value == '') {
          weGood = false;
          inputEl.addClass('validation-input-danger')
          .attr('aria-describedby', inputEl.prop('id') + 'Error')
          .parent().append('<span class="validation-message-danger"></span>')
          .find('.validation-message-danger')
          .prop('id', inputEl.prop('id') + 'Error')
          .html(msg);

          if (firstError === true) {
            firstError = false;
            inputEl.focus();
          }
        }
      });
      return weGood;    
    },

    demoValidate_paginated: function(e) {
      'use strict';

      var $this = $(e.currentTarget);
      var theForm = $('.hybrid-demo-active');
      var formInput = $('input, select', theForm);
      var weGood = true;
      var msg = 'Field cannot be blank';
      var firstError = true;

      formInput.each(function() {
        var inputEl = $(this);
        if (inputEl.prop('required') == '') {
          return 'non-false'; //continue
        }
        var value = inputEl.val();

        inputEl.removeClass('validation-input-danger')
        .parent().find('.validation-message-danger').remove();

        if (inputEl.is(':checkbox')) {
          return false; 
          //This T&C checkbox will be validated in demoValidate_terms()
        }
        else if (inputEl.is('select')) {
            value = $('option:selected:not(:first-child)', inputEl).text();
            msg = 'Please make a selection'
        }
        if (value == '') {
          weGood = false;
          inputEl.addClass('validation-input-danger')
          .attr('aria-describedby', inputEl.prop('id') + 'Error')
          .parent().append('<span class="validation-message-danger"></span>')
          .find('.validation-message-danger')
          .prop('id', inputEl.prop('id') + 'Error')
          .html(msg);

          if (firstError === true) {
            firstError = false;
            inputEl.focus();
          }
        }
      });
      return weGood;    
    },

    demoValidate_terms: function(e) {
      'use strict';
      var theBox = $('#tandc2');
      
      if (theBox.is(':checked') === true) {
        return true;
      }

      $('.terms-and-conditions').addClass('validation-danger')
      .find('.row').addClass('validation-fieldset-danger')
      .find('.checkbox').addClass('validation-input-danger')
      .find('input').attr('aria-describedby', theBox.prop('id') + '-error')

      theBox.closest('fieldset')
      .prepend('<div class="validation-message-danger"></div>')
      .find('.validation-message-danger')
      .append('<span>You must agree to the Terms &amp; Conditions</span>')
      .find('span').attr('role', 'alert')
      .prop('id', theBox.prop('id') + '-error');

      return false;
    }
  }
  /***************************************************************************/
  //End hybrid/paginated forms

});//END ALL THINGS



	/*
	 *	Add JS to build example JQPlot charts - this should not ship as part of
	 *	the DDL framework proper
	 *  reference: http://www.jqplot.com/docs/files/jqplot-core-js.html
	 ****************************************************************************/

    /*function buildSampleCharts(){

        $.jqplot.config.enablePlugins = true;

        var barChartExample = $('.chart #bar-chart-1');
        var barChartExampleData = [['Nov', 4900],['Dec', 1000],['Jan', -1000],['Feb', 5000], ['Apr', 3250]];

        if(barChartExample) {
               barChartExample.jqplot([barChartExampleData], {
                title:'',
                seriesColors:['#3675c2'],
                seriesDefaults:{
                    shadow: false,
                    renderer:$.jqplot.BarRenderer,
                    rendererOptions: {
                        //set any render options here
                    },
                    //force bars to render 'towards' 0 so negative values grow up and stop at 0
                    fillToZero: true,
                    fillToValue: 0,
                    fillAxis: 'y',
                    useNegativeColors: false // do not use a different color for negative values       
                },
                grid: {
                    shadow:false, 
                    borderWidth:0,
                    background: "transparent"
                },
                axes:{
                    xaxis:{
                        tickOptions:{
                            showGridline: false
                        },    
                        renderer: $.jqplot.CategoryAxisRenderer
                    },
                    yaxis:{
                        tickOptions:{formatString:"%'.2f"},
                        rendererOptions: {
                            drawBaseline: false
                        },
                        padMin: 1,
                        padMax: 1.2
                    }

                }
            }); 
        }

        //Donut Chart
            
        var donutChartExample = $('.chart #donut-chart-1');
        var donutChartExampleData = [['wedge 1',6], ['wedge 2',8], ['wedge 3',14], ['wedge 4',20], ['wedge 5',3], ['wedge 6',2], ['wedge 7',1], ['wedge 8',7], ['wedge 9', 11], ['wedge 10', 1]];
        
        if(donutChartExample){
            donutChartExample.jqplot([donutChartExampleData], {
              title:'',
              seriesColors:['#3675c2','#5c9fd6','#c95020','#d6814f','#821754', '#a64488', '#253269', '#4c64a1', '#287075', '#9bccc5'],
              legend: { show:true, location: 'e', placement: "insideGrid" },
              seriesDefaults: {
                shadow: false,
                // make this a donut chart.
                renderer:$.jqplot.DonutRenderer,
                rendererOptions:{
                  // Donut's can be cut into slices like pies.
                  sliceMargin: 1,
                  // Pies and donuts can start at any arbitrary angle.
                  startAngle: -30,
                  showDataLabels: false
                  // By default, data labels show the percentage of the donut/pie.
                  // You can show the data 'value' or data 'label' instead.
                  // dataLabels: 'value'
                }
              },
              grid: {
                    shadow:false, 
                    borderWidth:0,
                    background: "transparent"
              },
            });  
        }

        //Area Chart

        var areaChartExample = $('.chart #area-chart-1');

        var areaChartExampleData = [
          [35,45,55,40,39,48,20],
          [25,28,17,10,20,5,1]
        ];

        var areaChartExampleLabels = ["Area 1", "Area 2"]
        var areaChartExampleTicks = [[1, "2002"], [2, "2004"], [3, "2006"], [4, "2008"], [5, "2010"],
          [6, "2012"], [7, "2014"]];    // make the plot
        
        if(areaChartExample){
                areaChartExample.jqplot(areaChartExampleData, {
                title: '',
                seriesColors: ['#3675c2','#c95020'], //use rgba to set alpha on colors
                stackSeries: true,
                seriesDefaults: {
                    showMarker: false,
                    fill: true,
                    fillAndStroke: false
                },
                legend: {
                    show: true,
                    renderer: $.jqplot.EnhancedLegendRenderer,
                    placement: 'outsideGrid',
                    labels: areaChartExampleLabels,
                    location: 's',
                    rowSpacing: '0px',
                    rendererOptions: {
                        numberRows: 1
                    }
                },
                axesDefaults: {
                    labelRenderer: $.jqplot.CanvasAxisLabelRenderer
                },
                axes: {
                    xaxis: {
                        pad: 0,
                        ticks: areaChartExampleTicks,
                        label: 'Year',
                        tickOptions: {
                            showGridline: false
                        }
                    },
                    yaxis: {
                        min: 0,
                        max: 100,
                        label: '',
                        tickOptions: {
                          showGridline: true,
                          suffix: '%'
                        }
                    }
                },
                grid: {
                    drawBorder: false,
                    shadow: false,
                    background: 'rgba(0,0,0,0)'  //transparent
                    //background: 'white'
                }
            });
        }

        //Line Chart

        var lineChartExample = $('.chart #line-chart-1');

        var lineChartLine1 = [25,35,40,50,58,65,75,65,50,45,35,32];
        var lineChartLine2 = [30,40,45,55,63,70,80,83,50,45,35,28];
        var lineChartLine3 = [27,33,38,46,53,63,73,61,47,39,32,25];
        var lineChartLine4 = [11,17,25,28,31,35,40,33,31,23,20,17];

        var lineChartExampleTicks = [[1, "Jan"], [2, "Feb"], [3, "Mar"], [4, "Apr"], [5, "May"],
          [6, "Jun"], [7, "Jul"], [8, "Aug"], [9, "Sep"], [10, "Oct"], [11, "Nov"], [12, "Dec"]];  

        var lineChartExampleLabels = ["4 pt line", "Dotted line", "1 pt line", "2 pt line"]

        if(lineChartExample){
            lineChartExample.jqplot([lineChartLine1, lineChartLine2, lineChartLine3, lineChartLine4], 
                { 
                  title:'Line Style Options', 
                  // Set default options on all series, turn on smoothing.
                  seriesDefaults: {
                      rendererOptions: {
                          smooth: true
                      },
                      shadow: false
                  },
                  // Series options are specified as an array of objects, one object
                  // for each series.
                  series:[ 
                      {
                        //thick blue line
                        lineWidth:4, 
                        color: '#3675c2',
                        showMarker: false
                      }, 
                      {
                        //dotted line
                        lineWidth:2, 
                        color: '#821754',
                        linePattern: 'dotted',
                        showMarker: false
                      },
                      {
                        //very thin orange line
                        lineWidth:1, 
                        color: '#c95020',
                        showMarker: false
                      }, 
                      {
                        //thin green line
                        lineWidth:2, 
                        color: '#287075',
                        showMarker: false
                      }
                  ],
                grid: {
                    drawBorder: false,
                    shadow: false,
                    background: 'rgba(0,0,0,0)'  //transparent
                },
                axes: {
                        xaxis: {
                            pad: 0,
                            ticks: lineChartExampleTicks,
                            label: 'Month',
                            tickOptions: {
                                showGridline: false
                            }
                        },
                        yaxis: {
                            min: 0,
                            max: 100,
                            label: '',
                            tickOptions: {
                              showGridline: true,
                              suffix: '%'
                            }
                        }
                    },
                legend: {
                        show: true,
                        renderer: $.jqplot.EnhancedLegendRenderer,
                        placement: 'outsideGrid',
                        labels: lineChartExampleLabels,
                        location: 'ne',
                    }
               }
              );

            }  
        };

    buildSampleCharts(); //TODO jqplot causes an error (on build not locally) due to some issue with jqplot being built by grunt or bower depend

    */

function getQueryStringVars() {
  var vars = [], hash;
  var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
  var protocolRegExp = new RegExp(':\/\/', 'g');
  if (hashes.length === 1 && protocolRegExp.test(hashes[0])) {
    return false;
  } else {
    for(var i = 0; i < hashes.length; i++) {
      hash = hashes[i].split('=');
      vars.push({name: hash[0], class: hash[1]});
    }
    return vars;
  }
}
function UpdatePrototypeUrl () {
  var $AppliedModuleCardsContainer = $('#Applied-Module-Cards');
  var $UrlOutput = $('.url-output');
  var $ModuleLink = $('.module-link');
  var urlStr = window.location.protocol+'//'+window.location.host+'/configurator.html';
  var varPrefix = '?';
  $AppliedModuleCardsContainer.children().each(function () {
    var cardId = this.getAttribute('data-card-id');
    if (cardId) {
      urlStr += varPrefix+cardId;
      varPrefix = '&';
    }
  });

  $UrlOutput.html(urlStr);
  $ModuleLink.attr('href', urlStr);
}
