var iOS = (navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false );
var titleAttr = (iOS) ? 'title' : 'data-title';

$(function () {
    $('table').each(function() {
        var table = new CM.Table(this);
        table.init();
    });

    $('.sortable-table').each(function() {
        var table = new CM.TableSortable(this);
        table.init();
    });

    $('.input-table').each(function() {
        var table = new CM.TableInput(this);
        table.init();
    });

    $('.accordion').each(function() {
        var accordion = new CM.Accordion(this);
        accordion.init();
    });

    $('.accordion.form').each(function() {
        var form = new CM.AccordionForm(this);
        form.init();
    });

    $('.slider').each(function() {
        var options = {range: "min",
                       value: 1,
                       min: 1,
                       max: 5
                      };
        var slider = new CM.Slider(this, options);
        slider.init();
    });

    $('.inline-addition').each(function() {
        var addition = new CM.InlineAddition(this);
        addition.init();
    });

    /*
     * See http://amsul.ca/pickadate.js/date/ for description of datepicker options 
     */
    
    //configure datepicker options
    var datepickerOptions = {
        editable: false, //makes input readonly - you cannot type the date in
        weekdaysShort: ['S', 'M', 'T', 'W', 'T', 'F', 'S'], //configure day short forms
        showMonthsShort: false, //don't use short forms for months
        today: false, //do not show today btn
        clear: false, //do not show clear btn
        close: false, //do not show close btn

        onStart: function(context){
            var input = this.$node;
            var picker = this;
            input.click(function(e){
                
                /* Toggle Logic
                 * if the inout has focus  
                 * AND the picker is already open && we have just had a click
                 * then close the datepicker
                 ***/

                if(input.is(':focus') && picker.get('open')){
                    picker.close();
                    input.blur(); //if input is still focused it prevents the next toggle open
                }
            })

            input.on("change keyup paste", function(e){
                $(e.target).focus();
            })
        },

        // change input text color to blue when user makes a selection
        //TODO it does not appear possible to 'un-select' a date
        onSet: function(context) {
            this.$node.addClass('date-selected');
            this._hasBeenSelected = true;
        },

        //Add 'Today: ' to date if its === to today and a value hasn't been selected yet
        onRender: function(context){
            var prefixStr = 'Today: ';

           //give tab indexes to next/prev month & each day on the calendar
            $('.picker__nav--next, .picker__nav--prev, .picker__day').attr('tabindex','0');
            //focus whichever day recieves the datepikcer focus
            $('.picker__day--highlighted').focus(); 
            
            //handle blur on last day and return focus to first element
            //user can loop back to top and choose next/prev month or tab through again
            //user can press esc to leave the datepicker
            $('.picker__day').last().blur(function(e){
                $(e.target).closest('.picker__table').prev().find('.picker__nav--prev').focus();
            })

            //do not add today prefix it already exists
            if(!this._hasBeenSelected && this.$node.val().indexOf(prefixStr) === -1){
                var inputDate = new Date(this.get());
                var currentDate = new Date();

                if(inputDate.setHours(0,0,0,0) === currentDate.setHours(0,0,0,0)){
                    var inputValue = this.$node.val();
                    this.$node.val('Today: ' + inputValue);
                }
            }
        }

    };

    //initialize all datepickers
    //$('.datepicker').pickadate(datepickerOptions);

});