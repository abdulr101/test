(function ($, Drupal, window, document, undefined) {
	
  Drupal.behaviors.stayTouch = {
    attach: function(context, settings) {
      $('.stay-submit').on('click', function(event) {	  
	    event.preventDefault();
		var req = jQuery.ajax({
          url: Drupal.settings.basePath + "ibm_apim/stay/touch",
          type: "POST",
          data: {name : name,  email : email, confmail: confmail, company : company},
        });
	    req.done(function(msg) {
	      console.log(msg);	
        }
	  });
  };

})(jQuery, Drupal, this, this.document);

