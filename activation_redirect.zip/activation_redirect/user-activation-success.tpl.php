<?php
global $base_path;
$theme_path = $base_path . drupal_get_path('theme', 'citi_custom_theme');
?>
<!-- Modal two -->
        <div id="modal-login" class="modal fade city-modal active-window" role="dialog">
            <div class="modal-dialog modal-md">
                <!-- Modal content-->
                <div class="modal-content clearfix" style="
                     width: 900px;
                    margin-left: -154px;border-radius:0;" >
                    <div class="modal-header">
                        <div class="Activate">
                            <button type="button" class="close Circle-Fill" data-dismiss="modal"></button>
                            <h1 class="modal-title">Activate</h1>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="img-container">
                            <img src="<?php print $theme_path;?>/images/done.png">
                        </div>
                        <div class="title-container">
                            <h2>Your account has been successfully activated.</h2>
                            <span>Please log on using your newly created User ID and Password.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal two Ends -->