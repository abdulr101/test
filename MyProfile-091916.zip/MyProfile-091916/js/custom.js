$(document).ready(function()
{



 $(".form-inputs-registration,input[type=text],input[type=password],textarea").focus(function(){
	 $(this).prev().removeClass('txt-error');
	 $(this).removeClass('error');
      var sd = $(this).attr('placeholder');
		   
	  switch(sd)
	  {
		  case 'john':
		   $(this).prev().text('First Name');
          $(this).prev().css("visibility","visible");
		  break;
		  case 'smith':
		   $(this).prev().text('Last Name');
          $(this).prev().css("visibility","visible");
		  break;
		  default:
		   $(this).prev().text(sd);
          $(this).prev().css("visibility","visible");	
		  break;
		  
		
	  } 
	 
	
	
	 

    }); 
	$(".form-inputs-registration input[type=text],input[type=password],textarea").blur(function(){
     $(this).prev().css("visibility","hidden");
         
		$('#password_property').css("visibility","hidden");
		  
		  $('#new_password').removeClass('error');
	
	  
		  
    });
	
		$(".form-inputs-registration input[type=text],input[type=password],textarea").keydown(function(){
    
          $(this).prev().css("visibility","hidden");
	 
		  
    });
	
	
	$("#upload").change(function () {
$('#circle').css("visibility","hidden");
$('#hr').css("visibility","hidden");
$('#vr').css("visibility","hidden");
$('#click_to_browse').css("visibility","hidden");
$('#profilepic').css("display","none");
$('#change').css("display","block");

		 var countFiles = $(this)[0].files.length;
          var imgPath = $(this)[0].value;
          var extn = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase();
          var image_holder = $("#image-holder");
          image_holder.empty();
          if (extn == "gif" || extn == "png" || extn == "jpg" || extn == "jpeg") {
            if (typeof(FileReader) != "undefined") {
              //loop for each file selected for uploaded.
              for (var i = 0; i < countFiles; i++) 
              {
                var reader = new FileReader();
                reader.onload = function(e) {
                  $("<img />", {
                    "src": e.target.result,
                    "class": "thumb-image"
                  }).appendTo(image_holder);
                }
                image_holder.show();
                reader.readAsDataURL($(this)[0].files[i]);
              }
            } else {
              alert("This browser does not support FileReader.");
            }
          } else {
            alert("Pls select only images");
          }
    });
	
	
	$("#confirm_password").keyup(function()
	{
		var password=$("#new_password").val();
		if(password=="" || password==undefined)
		{
			$('#new_password').addClass('error');
			
		}
	});
	$("#confirm_password").change(function()
	{
		var password1=$("#new_password").val();
		var password2=$("#confirm_password").val();
		if(password1!="")
		{
		if(password1!=password2)
		{
			$('#confirm_password').addClass('error');
			$(this).prev().addClass('txt-error');
			  $(this).prev().text('Passwords do not match');
			
		}
		}
	});
	$("input[type=password]").focus(function(){
		 $(this).prev().removeClass('txt-error');
	 
    
	
	
});
	
$("#upload_link1").on('click', function(e){
     e.preventDefault();
    $("#upload:hidden").trigger('click'); 
	
});
$("#change").on('click', function(e){
     e.preventDefault();
    $("#upload:hidden").trigger('click'); 
	
});

 
	
	

	

	
	
		$( ".password").keyup(function(e) {  
		
	
		var password=$('.password').val();
	//Case sensitive
	if (password.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/)) 
	{
		$('.guide3').find("i").removeClass('glyphicon-remove');
			$('.guide3').find("i").addClass('glyphicon-ok');
			
		
	}
	else{
		$('.guide3').find("i").removeClass('glyphicon-ok');
		$('.guide3').find("i").addClass('glyphicon-remove');
			
		
	}
	
	
		//No more than 2 consecutive characters
	var len=password.length;

	  if (password.match(/(.)\1\1/))
	  {
				  $('.guide6').find("i").removeClass('glyphicon-ok');
			$('.guide6').find("i").addClass('glyphicon-remove');
			
			  
		  }
		  else{
			  $('.guide6').find("i").removeClass('glyphicon-remove');
			$('.guide6').find("i").addClass('glyphicon-ok');
			
		  }
	  
		// No leading or trailing whitespaces or in middle
	 var patt1 = /\s/g;
		  if (e.keyCode == 32 || password.match(patt1))
		{
			$('.guide2').find("i").removeClass('glyphicon-ok');
			$('.guide2').find("i").addClass('glyphicon-remove');

		}
		else
		{
			$('.guide2').find("i").removeClass('glyphicon-remove');
			$('.guide2').find("i").addClass('glyphicon-ok');

		}
	
		
		//if length is 8 characters or more, increase strength value
		if (password.length > 7 && password.length<51)
		{
			$('.guide1').find("i").removeClass('glyphicon-remove');
			$('.guide1').find("i").addClass('glyphicon-ok');
			
		}
		else{
			$('.guide1').find("i").removeClass('glyphicon-ok');
			
			$('.guide1').find("i").addClass('glyphicon-remove');
			
		}
			
		
		//if password contains both lower and uppercase characters, increase strength value
		if (password.match(/([a-z])/) || password.match(/([A-Z])/))
		{
			$('.guide4').find("i").removeClass('glyphicon-remove');
			$('.guide4').find("i").addClass('glyphicon-ok');
			
			
		}
		else{
			$('.guide4').find("i").removeClass('glyphicon-ok');
			$('.guide4').find("i").addClass('glyphicon-remove');
			
		}
		
		//if it has numbers and characters, increase strength value
		if (password.match(/([0-9])/))
		{
			$('.guide5').find("i").removeClass('glyphicon-remove');
			$('.guide5').find("i").addClass('glyphicon-ok');
			
		}
		else
		{
			$('.guide5').find("i").removeClass('glyphicon-ok');
			$('.guide5').find("i").addClass('glyphicon-remove');
			
		}
		
		//if it has one special character, increase strength value
		if (password.match(/([!,%,&,@,#,$,^,*,?,_,~])/))
		{
			$('.guide7').find("i").removeClass('glyphicon-remove');
			$('.guide7').find("i").addClass('glyphicon-ok');
			
		}
		else{
			$('.guide7').find("i").removeClass('glyphicon-ok');
			$('.guide7').find("i").addClass('glyphicon-remove');
			
		}
		var username=$(".User_ID_Name").text();
	
        if(password.indexOf(username) == -1)
		{
			$('.guide8').find("i").removeClass('glyphicon-remove');
			$('.guide8').find("i").addClass('glyphicon-ok');
		}
		else{
			$('.guide8').find("i").removeClass('glyphicon-ok');
			$('.guide8').find("i").addClass('glyphicon-remove');
			
		}
			if(len==0)
		{
			
			$('.guides').find("i").removeClass('glyphicon-ok');
			$('.guides').find("i").addClass('glyphicon-remove');
			
		}
		
		
		
	});	
	
	
	$( "#new_password").blur(function() { 
	
	$('.guides').each(function(){
	if($(this).find("i").hasClass('glyphicon-ok'))
	{
	
	}
	else{
	
	$('#new_password').addClass('error');		
	}
	});
	});
	
	
	
	
	
	
	
	

	$('.passwordDiv').keydown(function()
	{
		var password=$('.password').val();
		$('#password_property').css("visibility","visible");
		
		var result = checkStrength(password);
		$('#result').text(result);
	})	
	
	/*
		checkStrength is function which will do the 
		main password strength checking for us
	*/
	
	function checkStrength(password)
	{
		//initial strength
		var strength = 0
		
		//if the password length is less than 6, return message.
		if (password.length < 6) { 
			$('#result').removeClass()
			$('#result').addClass('Weak')
			return 'Weak' 
		}
		
		//length is ok, lets continue.
		
		//if length is 8 characters or more, increase strength value
		if (password.length > 7) strength += 1
		
		//if password contains both lower and uppercase characters, increase strength value
		if (password.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/))  strength += 1
		
		//if it has numbers and characters, increase strength value
		if (password.match(/([a-zA-Z])/) && password.match(/([0-9])/))  strength += 1 
		
		//if it has one special character, increase strength value
		if (password.match(/([!,%,&,@,#,$,^,*,?,_,~])/))  strength += 1
		
		//if it has two special characters, increase strength value
		if (password.match(/(.*[!,%,&,@,#,$,^,*,?,_,~].*[!,%,&,@,#,$,^,*,?,_,~])/)) strength += 1
		
		//now we have calculated strength value, we can return messages
		
		//if value is less than 2
		if (strength < 2 )
		{
		    $('#result').removeClass()
			$('#result').addClass('Fair')
			return 'Fair'			
		}
		else if (strength == 2 )
		{
			$('#result').removeClass()
			$('#result').addClass('Good')
			return 'Good'		
		}
		else
		{
			$('#result').removeClass()
			$('#result').addClass('Strong')
			return 'Strong'
		}
	}
	

	
	
	
	  function ValidateEmail(email) {
        var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        return expr.test(email);
    };
    $("#email").change(function () {
        if (!ValidateEmail($("#email").val())) {
			$("#email").addClass('error');
			$(".email-error").css("visibility","visible");
			
          
        }
        else {
			
			$(".email-error").css("visibility","hidden");
            
        }
    });
	$('#email').focus(function(){
		$("#email").removeClass('error');
		$(".email-error").css("visibility","hidden");
	});
	
	
	
	
	
	
	
	
	
	
	
	

});






