$(document).ready(function()
    {
    $(".country ").on({
    mouseenter : function() {
        $('.item-heading',this).addClass("hover");
    },
    mouseleave : function() {
        $('.item-heading',this).removeClass("hover");
    }
    

    })
	});
	$(function() {
  $('.countryselect').change(function(){
    $('.country').hide();
    $('.' + $(this).val()).show();
	
  });
});