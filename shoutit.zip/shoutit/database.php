<?php 

//Connect to MySQL
$con = mysqli_connet("localhost","root","","shoutit");
//$con = new PDO('mysql:host=localhost;dbname=shoutit;charset=utf8mb4', 'root', '');
//Test Connection

if(mysqli_connect_errno()) {
	echo 'Failed to connect to MySQL:' .mysqli_connect_errno();
	
} else { echo 'Conneciton Successful!';}


?>